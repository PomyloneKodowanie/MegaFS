package net.sf.webdav;

import java.security.Principal;

public interface ITransaction {

    Principal getPrincipal();

}
